
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
CREATE TABLE `clientorder` (
  `OrderID` int(10) NOT NULL,
  `clientorderId` int(11) NOT NULL,
  `ClientOrderNo` int(10) NOT NULL,
  `ClientName` varchar(20) NOT NULL,
  `OrderItem` int(11) NOT NULL,
  `ItemQty` int(10) NOT NULL,
  `ItemPrice` float NOT NULL,
  `orderStatus` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE `clients` (
  `ClientId` int(10) NOT NULL,
  `ClientName` varchar(50) NOT NULL,
  `ClientAddress` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE `products` (
  `ProdId` int(10) NOT NULL,
  `ProdDescription` varchar(50) NOT NULL,
  `ProdQuantity` int(10) NOT NULL,
  `ProdUnit` varchar(50) NOT NULL,
  `ProdUnitPrice` double NOT NULL,
  `ProdExpiry` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE `purchaseorder` (
  `PoID` int(10) NOT NULL,
  `PurchaseorderId` int(20) NOT NULL,
  `PurchaseorderNo` int(20) NOT NULL,
  `SupplierName` varchar(50) NOT NULL,
  `Orders` int(50) NOT NULL,
  `OrderQty` int(10) NOT NULL,
  `OrderPrice` float NOT NULL,
  `OrderStatus` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE `supplier` (
  `SupId` int(11) NOT NULL,
  `SupName` varchar(50) NOT NULL,
  `SupAddress` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE `users` (
  `UserID` int(10) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `UserPassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `users` (`UserID`, `UserName`, `UserPassword`) VALUES
(1, 'admin', 'admin');
ALTER TABLE `clientorder`
  ADD PRIMARY KEY (`OrderID`);
ALTER TABLE `clients`
  ADD PRIMARY KEY (`ClientId`);
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProdId`);
ALTER TABLE `purchaseorder`
  ADD PRIMARY KEY (`PoID`);
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SupId`);
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);
ALTER TABLE `clientorder`
  MODIFY `OrderID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9708;
ALTER TABLE `clients`
  MODIFY `ClientId` int(10) NOT NULL AUTO_INCREMENT;
ALTER TABLE `products`
  MODIFY `ProdId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
ALTER TABLE `purchaseorder`
  MODIFY `PoID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
ALTER TABLE `supplier`
  MODIFY `SupId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
ALTER TABLE `users`
  MODIFY `UserID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;