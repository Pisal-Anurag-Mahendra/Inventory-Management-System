$(document).ready( function () {
				$("#passicon").click(function(){
					$("#PasswordChange").show();
				});
                $(".close").click(function () {
			        $("#PasswordChange").hide();
		        });
});
