<footer>
    <hr style="margin-top:40px;">
    <p style="text-align:center;z-index:0;margin-top:10px;">© 2022 Inventory and Sales System By Chromatica</p>
</footer>